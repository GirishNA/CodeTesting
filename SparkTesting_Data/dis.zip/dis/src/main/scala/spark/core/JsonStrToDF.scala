package spark.core

import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._

object JsonStrToDF {
  val spark = SparkSession.builder()
    .master("local")
    .appName("testJson")
    .getOrCreate()

  import spark.implicits._

  def main(args: Array[String]): Unit = {
    jsonToDF
  }

  def jsonToDF(): Unit ={

  //  text: {"metadata":{"TableName":"CS.CS_INCIDENT_URGENCIES_TL","ColumnCount":11,"OperationName":"SELECT"},"data":{"INCIDENT_URGENCY_ID":"27","LANGUAGE":"US","SOURCE_LANG":"US","LAST_UPDATE_DATE":"2014-07-23T12:38:14.000+04:00","LAST_UPDATED_BY":"43053","CREATION_DATE":"2007-06-13T09:58:54.000+04:00","CREATED_BY":"4638","LAST_UPDATE_LOGIN":"24996686","NAME":"Priority 99","DESCRIPTION":"Max. Response in 1 Hr.","SECURITY_GROUP_ID":null},"before":null,"userdata":null,"__striimmetadata":{"position":null}} , key:metadata => Result:JObject(List(JField(TableName,JString(CS.CS_INCIDENT_URGENCIES_TL)), JField(ColumnCount,JInt(11)), JField(OperationName,JString(SELECT))))

    //struct<LAST_UPDATE_LOGIN:int,DESCRIPTION:string,NAME:string,INCIDENT_URGENCY_ID:int,SOURCE_LANG:string,CREATION_DATE:timestamp,CREATED_BY:int,LANGUAGE:string,LAST_UPDATE_DATE:timestamp,SECURITY_GROUP_ID:int,LAST_UPDATED_BY:int>
      val jsonStr = """{"INCIDENT_URGENCY_ID":27,"LANGUAGE":"US","SOURCE_LANG":"US","LAST_UPDATE_DATE":"2014-07-23T12:38:14.000+04:00","LAST_UPDATED_BY":"43053","CREATION_DATE":"2007-06-13T09:58:54.000+04:00","CREATED_BY":"4638","LAST_UPDATE_LOGIN":"24996686","NAME":"Priority 99","DESCRIPTION":"Max. Response in 1 Hr.","SECURITY_GROUP_ID":null}"""

      val row = Row(jsonStr)
    val schema = StructType(Seq(StructField("data",StringType,true)))

   val structField1 = List(StructField("INCIDENT_URGENCY_ID",IntegerType,true),
     StructField("LANGUAGE",StringType,true), StructField("SOURCE_LANG",StringType,true),
     StructField("LAST_UPDATE_DATE",TimestampType,true),
     StructField("LAST_UPDATED_BY",IntegerType,true),
     StructField("CREATION_DATE",TimestampType,true),
     StructField("CREATED_BY",IntegerType,true),
     StructField("LAST_UPDATE_LOGIN",IntegerType,true),
     StructField("NAME",StringType,true),
     StructField("DESCRIPTION",StringType,true),
     StructField("SECURITY_GROUP_ID",IntegerType,true))

    val structField = List(StructField("LANGUAGE",StringType,true),StructField("INCIDENT_URGENCY_ID",IntegerType,true),
       StructField("SOURCE_LANG",StringType,true),
      StructField("LAST_UPDATE_DATE",StringType,true),
      StructField("LAST_UPDATED_BY",StringType,true),
      StructField("CREATION_DATE",StringType,true),
      StructField("CREATED_BY",StringType,true),
      StructField("LAST_UPDATE_LOGIN",StringType,true),
      StructField("NAME",StringType,true),
      StructField("DESCRIPTION",StringType,true),
      StructField("SECURITY_GROUP_ID",StringType,true))

    val schema1 = StructType(structField)
    val schema2 = StructType(structField1)
//    val df = spark.read.json(spark.sparkContext.parallelize(Seq(jsonStr)))
    val df = spark.createDataFrame(spark.sparkContext.parallelize(Seq((row))),schema)

    df.show()

   println("---->"+df.collectAsList())

      val df1 = df.select(from_json($"data",schema1) as "data1")
        .select("data1.*")
          .withColumn("CREATION_DATE",$"CREATION_DATE".cast(TimestampType))

    df1.show()

    df1.printSchema()

   val finalRes= withCol(df1,schema2)
    finalRes.show()
    finalRes.printSchema()
  }

  def withCol(df:DataFrame,schema:StructType): DataFrame ={
    var res = df
    schema.fields.map(eachF=>
    res = res.withColumn(eachF.name,col(eachF.name).cast(eachF.dataType))
    )
    res
  }


}
