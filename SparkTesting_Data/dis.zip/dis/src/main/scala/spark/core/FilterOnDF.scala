package spark.core

import org.apache.spark.sql.SparkSession

object FilterOnDF {
  val spark = SparkSession.builder().master("local").appName("test").getOrCreate()

  def main(args: Array[String]): Unit = {
    filterNotNull
  }

  def filterNotNull(): Unit ={

    val json = """[{"id":null,"name":'2015-11-02 17:37:56'},{"id":'2',"name":'2015-11-02 17:37:56'},{"id":'3',"name":null}]"""

    val df = spark.read.json(spark.sparkContext.parallelize(Seq(json)))

    df.show()

    df.printSchema()

    val dfFilter=df.filter("name!='null' AND id!='null'")
        //.filter("id!='null'")

    dfFilter.show()

  }

}
