package spark.core

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

object JsonToDF {

  val spark=SparkSession.builder().appName("test").getOrCreate()

  def main(args: Array[String]): Unit = {
    jsonToDF()
  }

  def jsonToDF(): Unit ={
    val jsonStr = """{"id":"1","addres":[{"name":"giri","loc":"banglore"},{"name":"giri123456"}]}"""

    val df = spark.read.json(spark.sparkContext.parallelize(Seq(jsonStr)))
    df.show()
    val df1 = df.withColumn("jsonArr",explode(col("addres")))
      .withColumn("name",col("jsonArr.name"))
      .withColumn("loc",col("jsonArr.loc"))
        .select("id","name","loc")

      df1.show()

    val uniqValue = df1.dropDuplicates("id","name")

    uniqValue.show()
  }

}
