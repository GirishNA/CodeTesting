package spark.core

import org.apache.spark.sql.types._

object GenStructType {

  def main(args: Array[String]): Unit = {


    val l = List(("id","NUMBER"),("NAME","VARCHAR2(20 BYTE)"),("DATET","DATE"))
   val x = l.map{
        eachCol =>
         genStructType(eachCol._1,eachCol._2)
      }

   // println("---------"+x.apply(1).mkString)

    val structType = StructType(x.toSeq)


    println("---------->"+structType.apply("id"))
    println("---------->"+structType.simpleString)

  }

  def genStructType(col:String,dataTypeStr:String): StructField ={
   // val structType = new StructType()
    println(dataTypeStr+"------->"+col)
    println("------->"+getDataType(dataTypeStr))
      StructField(col,getDataType(dataTypeStr))
  }

  def getDataType(colDataType:String): DataType ={

    val doubleD = """^NUMBER+[(]+\d+,+\d+[)]""".r
    val doubleD1 = """^NUMBER+[(]+\d+[)]""".r
    val strD = """VARCHAR2+[(]+\d BYTE+[)]""".r
    colDataType match {
      // case "NUMBER" => s""".withColumn("${colName}",col("${colName}").cast(IntegerType))"""
      case doubleD()|"NUMBER"|doubleD1()|"DOUBLE"=> DoubleType
      case strD() => StringType
      case "DATE"|"TIMESTAMP" => TimestampType
      case "RAW" => BinaryType
      case _ => StringType
    }
  }
}
