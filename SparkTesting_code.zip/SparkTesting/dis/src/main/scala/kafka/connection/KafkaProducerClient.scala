package kafka.connection

import rtbi.dis.config.LoadResources

object KafkaProducerClient {
  
  val defaultTopic="ISSA"
  
  val issaProp=LoadResources.returnAsProperties("/dis.properties")
  
  val kafkaQueue=new KafkaProducer(Some(defaultTopic),issaProp.getProperty("propertiesFileName"))
  
  
  
  def main(args:Array[String])
  {
    
    (0 to 10).foreach(message=> kafkaQueue.send(s"------------------------------------------------> girish \t$message","1"))
  }
}