package kafka.connection

import kafka.producer.Producer
import kafka.producer.ProducerConfig
import rtbi.dis.config.LoadResources
import kafka.producer.KeyedMessage


class KafkaProducer(defaultTopic:Option[String],propertyFileName:String) {
  
  private val producer=new Producer[AnyRef,AnyRef](new ProducerConfig(LoadResources.returnAsProperties(propertyFileName)))
  
  def sendMessage(message:String,partitionName:Option[String]=None,topic:Option[String]):KeyedMessage[AnyRef,AnyRef]=
  {
    val topicName=topic.getOrElse(defaultTopic.getOrElse(throw new IllegalArgumentException("Please specify the topic name")))
    require(!topicName.isEmpty,"Topic should not be empty")
    
    partitionName match
    {
      case Some(k) => new KeyedMessage(topicName,k.getBytes("UTF8"),message.getBytes("UTF8"))
      case _ => new KeyedMessage(topicName,message.getBytes("UTF8"))
    }
  }
  
  def send(key:String,value:String,topic:Option[String]=None)
  {
    producer.send(sendMessage(value,Option(key),topic))
  }
  
  def send(value:String,topic:Option[String])
  {
    send(null,value,topic)
  }
  
  def send(value:String,topic:String)
  {
    send(null,value,Option(topic))
  }
  
  def send(value:String)
  {
    send(null,value,None)
  }
  
}
