package datamigration

import java.sql.DriverManager
import rtbi.spark.sparkConnect.SparkConnection
import com.mongodb.util.JSON
import com.mongodb.Mongo
import com.mongodb.DB
import com.mongodb.DBObject
import org.json.JSONObject


object OracleToMongo {
  
  val ss=SparkConnection.sparkSession
  def main(args:Array[String])
  {
   //  mysqlConnect 
   //  mysqlToJson
   //  mongoConnect
  // scalaMongo
   // mongoConnect
  //  javaMongo
    
    readInnerData()
  }
  
  def mysqlConnect()
  {
    Class.forName("com.mysql.jdbc.Driver")
    val connect=DriverManager.getConnection("jdbc:mysql://localhost/giri", "root", "root")
    val stat=connect.createStatement()
    val res=stat.executeQuery("select * from user")
    
    while(res.next())
    {
      val name=res.getString("name")
      println("--->"+name)
    }
  }
  
  def mysqlToJson()
  {
    var obj=new JSONObject();
    val dbConnect=ss.read.format("jdbc").option("url", "jdbc:mysql://localhost/giri")
                      .option("driver", "com.mysql.jdbc.Driver")
                      .option("user", "root")
                      .option("password", "root")
                      .option("dbtable", "user").load()
                      
      val data= dbConnect.toJSON   
      
    val lt=data.collectAsList()
    
    println(lt)
    
    for(i<-0 to lt.size()-1)
    {
      val x=JSON.parse(lt.get(i)).asInstanceOf[DBObject]
      
     javaMongo(x)
    //  println("--->"+obj)
    }
    
   println("giri--->"+obj)
    
  //  val obj=new BasicDBObject("emp1",data)
    
   // mongoConnect(obj)
   
   
   
  }
  
 /*
  def mongoConnect(ob:Object)
  {
   // val obj:BasicDBObject=null;
    
    
     println("------------------>")
    val connet=MongoClient("localhost")
    var dbConnect=connet.getDB("giri123")
   val auth= dbConnect.authenticate("", "")
   val db= dbConnect.getCollection("user")
   
   //val conv=MongoDBObject.newBuilder
   
  val d=ob.asInstanceOf[DBObject]
   
  // val insert=new BasicDBObject("name","MongoDB").append("name", "123asdfgh")
     //insert.append("name", "girish")
    
  //val insert=new BasicDBObject(ob)
     
     obj.append("emp", ob)
     
     println(obj)
     
     //val x=db.insert(ob.asInstanceOf[DBObject])
   
   val x=db.insert(d)
     
     println("--->"+x)
   
   val data=db.find()
  while(data.hasNext())
  {
    println("g-->"+data.next())
  }
   
    
    //val connect11=MongoConnection("localhost")
    //val dat=connect("giri123")("user")
    println("------------------>")
    
    
    
    
  }*/
  
  
  /*def scalaMongo()
  {
    println("---->")
    
    val connt=MongoClient("mongodb://localhost")
    val db=connt.getDatabase("giri123")
    
    val d=db.getCollection("user")
    
    val res=d.find().collect()
//    while(res.co)
    println(res)
    
    for(x<-res.collect())
    {
      println("---->"+x)
    }    
    
 }*/
  
  def javaMongo(obj:DBObject)
  {
    val con=new Mongo("localhost",27017)
    val db=con.getDB("giri123").getCollection("user")
    
    db.insert(obj)
    
    val res=db.find()
    while(res.hasNext())
    {
      println(res.next())
    }
  }
  
  
  def readInnerData()
  {
    var obj=new JSONObject();
    var obj1=new JSONObject();
    val dbConnect=ss.read.format("jdbc").option("url", "jdbc:mysql://localhost/giri")
                      .option("driver", "com.mysql.jdbc.Driver")
                      .option("user", "root")
                      .option("password", "root")
                      //.option("dbtable", s"(select * from emp) AS tmp").load()
                      
      val empData=dbConnect.option("dbtable", s"(select * from emp) AS tmp").load()
      
      val deptData=dbConnect.option("dbtable", "dept").load()
      
      empData.show()
      deptData.show()
      
      val e=empData.select("id")
     /* var l=List.empty[Any]
      e.map(x=>l+:=x)*/

     println( e.count().toInt)
     val idCounter=e.count().toInt
     
     
     for(i<-1 to idCounter)
     {
      
       val filterEmp=empData.filter(s"id=$i").toJSON
      // obj+=JSON.parse(filterEmp.toString())
       
        val o=new JSONObject((filterEmp.collectAsList().get(0)))
       
      
       
       println(filterEmp.collectAsList())
      // obj.append("emp", filterEmp.collectAsList().get(0))
       
       obj.put("emp", JSON.parse(filterEmp.collectAsList().get(0)))
       
       println("-------->"+obj)
      val filterData=deptData.filter(s"id=$i").toJSON
      println(filterData.collectAsList())
       obj.put("emp", filterData.collectAsList())
       
       println("*******>"+obj)
       
        o.put("details",JSON.parse(filterData.collectAsList().toString()) )
       println("json object---->"+o)
     }                
    
    //select * from emp e join dept d on e.id = d.id
                      
    /*  val edata= empData.toJSON
      val ddata= deptData.toJSON
      
      println(edata.collectAsList())
      println(ddata.collectAsList())*/
      
    
  }
  
 
  
}