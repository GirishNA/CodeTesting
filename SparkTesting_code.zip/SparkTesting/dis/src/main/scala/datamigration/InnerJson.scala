package datamigration

import rtbi.spark.sparkConnect.SparkConnection
import org.json.JSONObject
import com.mongodb.util.JSON
import com.mongodb.DBObject
import com.mongodb.Mongo
import com.mongodb.BasicDBObject
import com.mongodb.BasicDBObjectBuilder
import org.apache.spark.sql.DataFrameReader

object InnerJson {
   val ss=SparkConnection.sparkSession
  def main(args:Array[String])
  {
     val levelOneChield=List("dept","bank")
     val levelTwoChield=Map("bank"->List("bankDetails"))
     val masterTable="emp"
     val foreignKey="id"
     val levelTwoForeignKey="bankId"
    
     innerJson(levelOneChield,masterTable,foreignKey,levelTwoChield,levelTwoForeignKey)
  }
   
   def dbConnect():DataFrameReader=
   {
     val dbConnect=ss.read.format("jdbc").option("url", "jdbc:mysql://localhost/giri")
                      .option("driver", "com.mysql.jdbc.Driver")
                      .option("user", "root")
                      .option("password", "root")
                      //.option("dbtable", s"(select * from emp) AS tmp").load()
       dbConnect;
   }
  
  def innerJson(levelOneChield:List[String],masterTable:String,foreignKey:String,levelTwoChield:Map[String,List[String]],levelTwoForeignKey:String)
  {
      val empData=dbConnect.option("dbtable", s"(select * from $masterTable) AS tmp").load()
      val empIdSize=empData.select(foreignKey).count().toInt
  
      for(i<-1 to empIdSize)
      {
         var obj=new JSONObject(empData.filter(s"$foreignKey=$i").toJSON.collectAsList().get(0))
        
         for(tableName<-levelOneChield)
          {
            
            val levelOneData=dbConnect.option("dbtable", tableName).load()             
        
            obj.put(s"$tableName",JSON.parse(levelOneData.filter(s"$foreignKey=$i").toJSON.collectAsList().toString()))
        
          
              println("---->\t"+obj)
                   
     //   javaMongo(JSON.parse(obj.toString()).asInstanceOf[DBObject])      
       
       
      }
         println("---->"+obj)
        
      
      }      
   //   javaMongo(JSON.parse(finalObj.toString()).asInstanceOf[DBObject])   
  }
  
  
  
  def levelTwo(levelTwoList:List[String],levelTwoForeignKey:String):String=
  {
     for(levelTwoTable<-levelTwoList)
       {
         println("----->"+levelTwoTable)
       val levelTwoData=dbConnect.option("dbtable",levelTwoTable).load()
       val lt=levelTwoData
       }
     ""
  }
  
  
 
  def javaMongo(obj:DBObject)
  {
    val con=new Mongo("localhost",27017)
    val db=con.getDB("giri123").getCollection("emp")
    
    db.insert(obj)
    
    val res=db.find()
    while(res.hasNext())
    {
      println(res.next())
    }
  }
  
}