package datamigration

import com.mongodb.Mongo

object ChieldIDCreateInMongo {
  
  def main(args:Array[String])
  {
    chieldIdCreate
  }
  
  def chieldIdCreate()
  {
    val dbConnect=new Mongo("192.168.0.108",27017)
    val db=dbConnect.getDB("giri123").getCollection("emp")
    
     val res=db.find()
     
     while(res.hasNext())
     {
       println("--->"+res.next())
     }
  }
  
}