package datamigration

import rtbi.spark.sparkConnect.SparkConnection
import org.json.JSONObject
import com.mongodb.util.JSON
import com.mongodb.DBObject
import com.mongodb.Mongo
import com.mongodb.BasicDBObject
import com.mongodb.BasicDBObjectBuilder
import org.apache.spark.sql.{DataFrame,DataFrameReader}
import org.json.JSONArray
import scala.collection.immutable.HashMap


object LevelTwoJson {
  val ss=SparkConnection.sparkSession
  def main(args:Array[String])
  {
     //Master table details
     val masterTable="emp"
     val masterPK=Map("emp"->"id")
     
     //Level One table details
     val levelOneChield=List("dept","bank")
     val levelOnePK=Map("dept"->"depid","bank"->"bankId")
     val levelOneFK=Map("dept"->"id","bank"->"id")
     
    //Level Two table details
     val levelTwoChield=Map("bank"->List("bankDetails"))
     val levelTwoFK=Map("bankDetails"->"bankId")
     
     
     //"bank"->List("bankDetails")
     
     
    println("----->"+masterPK(masterTable))
    
    innerJson(levelOneChield,masterTable,levelOneFK,levelTwoChield,levelTwoFK,masterPK,levelOnePK)
  }
   
   def dbConnect():DataFrameReader=
   {
     val dbConnect=ss.read.format("jdbc").option("url", "jdbc:mysql://localhost/giri")
                      .option("driver", "com.mysql.jdbc.Driver")
                      .option("user", "root")
                      .option("password", "root")
                      //.option("dbtable", s"(select * from emp) AS tmp").load()
       dbConnect;
   }
  
  def innerJson(levelOneChield:List[String],
                masterTable:String,
                levelOneFK:Map[String,String],
                levelTwoChield:Map[String,List[String]],
                levelTwoFK:Map[String,String],
                masterPK:Map[String,String],
                levelOnePK:Map[String,String])
  {
     
    var primaryKeyList=List.empty[String] 
                      
                      
      val empData=dbConnect.option("dbtable", s"(select * from $masterTable) AS tmp").load()
      
      
      
     // val empIdSize=empData.select(foreignKey).count().toInt
      

     var primaryKeyData=empData.select(masterPK(masterTable))
        
     for(masterKeys<-primaryKeyData.collect())
     {
      primaryKeyList+:=(masterKeys.get(0).toString())    
     }
   
      
      for(key<-primaryKeyList.sorted)
      {
        println(key)
         
        
         var finalObj=new JSONObject(empData.filter(s"${masterPK(masterTable)}=$key").toJSON.collectAsList().get(0))
        
         for(tableName<-levelOneChield)
          {
          
             println("--->"+tableName)
            val levelOneData=dbConnect.option("dbtable", tableName).load()           
            
        
          //  obj.put(s"$tableName",JSON.parse(levelOneData.filter(s"$foreignKey=$i").toJSON.collectAsList().toString()))
        
           // println("gggg--->"+levelOneData.filter(s"$foreignKey=$i").toJSON.collectAsList())
            
                if(levelTwoChield.contains(tableName))
                {
               
                //  val levelOneCount=levelOneData.select(levelTwoForeignKey).count().toInt
                 /* for(key <- 1 to levelOneCount)
                  {*/
                  
                    println("key---->"+key)
                    //var levelOneObj=new JSONObject(levelOneData.filter(s"${foreignKey(tableName)}=$key").toJSON.collectAsList().get(0))
                   /*// println(levelOneCount)
             
                // levelTwo(levelTwoChield(tableName),levelTwoForeignKey)
                    println("***--->"+levelOneObj.put("abc", s"ggggggggg--->$key"))
                      y=levelOneObj
                      
                     
                      
                    //  finalObj.append("xyz",levelOneData.filter(s"$foreignKey=$x").toJSON.collectAsList())
                      
                    //  finalObj.append("xyz", a)
									*/                      
                     
                    levelOneMaster(levelOneData,tableName,finalObj,levelOneFK(tableName),levelOnePK(tableName),levelTwoFK,levelTwoChield(tableName),key)
                   
                     // obj.append(tableName, JSON.parse(levelTwoChieldTable(levelTwoChield(tableName),levelTwoForeignKey,key,levelOneObj).toString()))
                      
                 
                     
                //  }
                
                }
                else
                {
                  val levelOneJson=levelOneData.filter(s"${levelOneFK(tableName)}=$key").toJSON.collectAsList()
                  if(!levelOneJson.isEmpty())
                  {
                     finalObj.put(tableName, JSON.parse(levelOneJson.toString()))
                  }
                }
       
            // println("final---->\t"+obj)
            
       // println("\t"+levelOneObj)
       // finalObj.append("master",obj)
        
     //   javaMongo(JSON.parse(obj.toString()).asInstanceOf[DBObject])      
       
      
      
     
      }
         println("final---->"+finalObj)
         // finalObj.append("master",obj)
          
      
      }
      
    //  println("---->"+finalObj.get("master"))
      
   //   javaMongo(JSON.parse(finalObj.toString()).asInstanceOf[DBObject])   
  }
  
  
  
  def levelOneMaster(levelOneData:DataFrame,
                     tableName:String,
                     finalObj:JSONObject,
                     levelOneFK:String,
                     levelOnePK:String,
                     levelTwoFK:Map[String,String],
                     levelTwoChield:List[String],
                     masterKey:String)
  {
    var primaryKey=List.empty[String]
    
      val levelOneFKData=levelOneData.filter(s"$levelOneFK=$masterKey")   
      
      
      for(eachKey<-levelOneFKData.select(levelOnePK).collect())
      {
        primaryKey+:=eachKey.get(0).toString()
      }
    
      for(key<-primaryKey)
      {
         //var levelOneObj=new JSONObject(levelOneData.filter(s"${levelOneFK}=$key").toJSON.collectAsList().get(0))
        
         var levelOneObj=new JSONObject(levelOneData.filter(s"$levelOnePK=$key").toJSON.collectAsList().get(0)) 
         finalObj.append(tableName, JSON.parse(levelTwoChieldTable(levelTwoChield,levelTwoFK,key,levelOneObj).toString()))
         println("1111----->"+finalObj)
      }
  }
  
  
  
  def levelTwoChieldTable(levelTwoList:List[String],levelTwoFK:Map[String,String],key:String,levelOneObj:JSONObject):JSONObject=
  {
    
     for(levelTwoTable<-levelTwoList)
       {
         println("----->"+levelTwoTable)
         val levelTwoData=dbConnect.option("dbtable",levelTwoTable).load().filter(s"${levelTwoFK(levelTwoTable)}=$key").toJSON.collectAsList()
         if(!levelTwoData.isEmpty())
         {
           levelOneObj.put(levelTwoTable,JSON.parse(levelTwoData.toString()))
           println("two"+levelOneObj)
         }
       }
    levelOneObj
  }
  
  
 
  def javaMongo(obj:DBObject)
  {
    val con=new Mongo("localhost",27017)
    val db=con.getDB("giri123").getCollection("emp")
    
    db.insert(obj)
    
    val res=db.find()
    while(res.hasNext())
    {
      println(res.next())
    }
  }
}