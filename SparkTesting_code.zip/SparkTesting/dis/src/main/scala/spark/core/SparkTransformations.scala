package spark.core

import org.apache.spark.SparkContext
import rtbi.spark.sparkConnect.SparkConnection

object SparkTransformations {
  
  val sc=SparkConnection.sparkContex
  def main(args:Array[String])
  {
    val filePath="/home/vtpl/StudentData1.txt"
    testPgm(filePath)
  }
  
  def testPgm(filePath:String)
  {
    val readFile=sc.textFile(filePath, 2)
    
    readFile.collect().map(x=>println(x))
    
    println(readFile.cache())
   //  println(readFile.dependencies)
    
    val lineLength=readFile.map(x=>x.length())
    
    lineLength.map(y=>println("--->"+y))
    
    val totalLength=lineLength.reduce((a,b)=>a+b)
    
    println(totalLength)
    
    println("--->"+lineLength.persist().map(x=>println(x)))
    
  }
}