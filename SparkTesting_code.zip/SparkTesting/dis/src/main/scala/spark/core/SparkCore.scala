package spark.core

import org.apache.spark.sql.SparkSession

object SparkCore {
  
  val ss=SparkSession.builder().master("local").appName("sparkCore").getOrCreate()
  val sc=ss.sparkContext
  
  import ss.implicits._
  
  def main(args:Array[String])
  {
  //  broadcast
   // accumulators
    mysqlToJson
  }
  
  def broadcast()
  {
    val bc=sc.broadcast(Array("a",2,3,'b'))
   
    bc.value.map(x=>println(x))
    //println("--->"+bc.value)
  }
  
  def accumulators()
  {
    val acc=sc.accumulator(0)
    
    val p=sc.parallelize(Seq(1,2,3,4))
    
    p.foreach(x=>acc+=x)
    
    println("--->"+acc.localValue)
    
    
  }
  
  def mysqlToJson()
  {
    val dbConnect=ss.read.format("jdbc").option("url", "jdbc:mysql://localhost/giri")
                      .option("driver", "com.mysql.jdbc.Driver")
                      .option("user", "root")
                      .option("password", "root")
                      .option("dbtable", "user").load()
                      
      val data= dbConnect.toJSON   
      val x=data.collectAsList()
      println(x)
  }
  
}