package spark.stream

import rtbi.spark.sparkConnect.SparkConnection
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.Seconds


import org.apache.spark.sql.functions._

object StreamData {
  
  val sparkContext=SparkConnection.sparkContex
  val sparkSession=SparkConnection.sparkSession
  
  def main(args:Array[String])
  {
    streamData
  }
  
  
  def streamData()
  {
   /* val stream=new StreamingContext(sparkContext,Seconds(1))
    
    val data=stream.socketTextStream("localhost", 9999)
    
    val word=data.flatMap(_.split(" "))
    
    val pair=word.map(w=>(w,1))
    
    val count=pair.reduceByKey(_+_)
    
      count.print()    */
    //println("---->"+data)
    
      val str=sparkSession.readStream.format("socket").option("host", "192.168.0.252").option("port", 9999).load()
      
     // str.show()
      
      val words=str.groupBy("value").count()
      
      
      val d=words.writeStream.outputMode("complete").format("console").start()
    
      d.awaitTermination()
    
  //  stream.start()
   // stream.awaitTermination()
    
  }
}