package rtbi.dis.config

import java.text.SimpleDateFormat
import java.util.Date

class CommonMethod {
  /*
   * This getDateTime() method is used to get the current date in the format of 'ddMMyyyy'
   */
  def getDateTime():String=
  {
    var currentDate:String=null;
    try{
      val dateFormat=new SimpleDateFormat("ddMMyyyy");
       currentDate=dateFormat.format(new Date());
      println("hiiiiiii\t"+currentDate);
    }
    catch{
      case e:Exception=>e.printStackTrace()
    }
    currentDate;
  }  
}