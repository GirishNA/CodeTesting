package rtbi.dis.config.kafka

class KafkaReciver {
  
}