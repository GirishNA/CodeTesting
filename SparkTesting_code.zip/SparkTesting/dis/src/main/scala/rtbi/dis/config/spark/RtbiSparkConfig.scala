package rtbi.dis.config.spark

import org.apache.spark.SparkContext

import org.apache.spark.SparkConf
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.Seconds
import rtbi.dis.config.LoadResources
import java.util.Properties

object RtbiSparkConfig  extends Serializable{
  
  
   // load  and set  the spark properties
  
  def sparkContextCreator(sparkConfig:Properties):SparkContext ={
    val conf = new SparkConf()
     // .setMaster(sparkConfig.getProperty("spark.master"))
      .setAppName(sparkConfig.getProperty("spark.AppName"))
      .set("spark.executor.memory", sparkConfig.getProperty("spark.executor.memory"))
      .set("spark.rdd.compress",sparkConfig.getProperty("spark.rdd.compress"))
      .set("spark.storage.memoryFraction", sparkConfig.getProperty("spark.storage.memoryFraction"))
      .set("spark.streaming.unpersist", sparkConfig.getProperty("spark.streaming.unpersist"))
      .set("spark.eventLog.enabled", sparkConfig.getProperty("spark.eventLog.enabled"))
      .set("spark.eventLog.compress", sparkConfig.getProperty("spark.eventLog.compress"))
      .set("spark.serializer", sparkConfig.getProperty("spark.serializer"))
      .set("num-executors", sparkConfig.getProperty("num-executors"))
      .set("executor-cores", sparkConfig.getProperty("executor-cores"))
      new SparkContext(conf)
   
    }
  
 // Cretaing Spark Streaming Context 
  
   def sparkStreamContextCreator(resourceFile: String):StreamingContext={
         val sparkConfig:Properties= LoadResources.returnAsProperties(resourceFile)
         val sc=sparkContextCreator(sparkConfig)
         new StreamingContext(sc, Seconds(sparkConfig.getProperty("timeInSeconds").toInt))
   }
   
}