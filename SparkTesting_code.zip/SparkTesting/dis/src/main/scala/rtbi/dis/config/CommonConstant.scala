package rtbi.dis.config
/*
 * Created By Girish A N
 * This class is used to declare the all variables and these variables used in the all project  
 */
object CommonConstant {
  var validFTPZipFiles:Int=0;
  var inValidFTPZipFiles:Int=0;
  var totalFTPZipFiles:Int=0;
  var totalLocalZipFiles:Int=0;
  var validLocalZipFiles:Int=0;
  var inValidLocalZipFiles:Int=0;
  var validFiles:Int=0;
  var inValidFiles:Int=0;
  
  
  
  /*
   * Audit Table Status
   */
  val success:String="SUCCESS";
  val error:String="ERROR";
  val running:String="RUNNING"; 
}