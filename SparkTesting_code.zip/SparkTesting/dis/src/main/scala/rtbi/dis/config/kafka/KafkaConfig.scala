package rtbi.dis.config.kafka

import java.io.Serializable
import java.util.Properties
import scala.collection.immutable.HashMap
import rtbi.dis.config.ConstConfig
import java.lang.Boolean
import java.lang.Double

object RTBIKafkaConfig extends Serializable   {
    val dummyKafkaParams = Map("metadata.broker.list" -> "192.168.0.211:6667")
    var _fetchSizeBytes:Int  = 512 * 1024
    var _fillFreqMs :Int = 200
    var _minFetchSizeBytes:Int = 1 * 1024
    var _bufferSizeBytes:Int = _fetchSizeBytes
    var  _refreshFreqSecs:Int = 60
    var  _socketTimeoutMs:Int = 10000
    var  _forceFromStart:Boolean = false
    var _stopGracefully:Boolean = true
    var  _backpressureEnabled:Boolean = false
    var  _startOffsetTime:Long = kafka.api.OffsetRequest.EarliestTime
    var  _useStartOffsetTimeIfOffsetOutOfRange:Boolean = true
    var _stateUpdateIntervalMs:Long = 2000
    var  _stateConf:Map[String,String]=_
   
  // Parameters related to Back Pressure
  var  _proportional:Double = 0.75
  var   _integral:Double = 0.15
  var  _derivative:Double = 0

     
    def rtbiKafkaConfig( props:Properties) {

     val zkHost= props.getProperty("zookeeper.hosts");
    val  zkPort = props.getProperty("zookeeper.port");
    
    val  kafkaTopic = props.getProperty("kafka.topic");
    val brokerZkPath = props.getProperty("zookeeper.broker.path");

    val  consumerZkPath = props.getProperty("zookeeper.consumer.path");
    val  consumerConnection =
        props.getProperty("zookeeper.consumer.connection");
    val consumerId = props.getProperty("kafka.consumer.id");

   if (props.getProperty("consumer.forcefromstart") != null)
      _forceFromStart =
          Boolean.parseBoolean(props.getProperty("consumer.forcefromstart"));

   
    if (props.getProperty("consumer.fetchsizebytes") != null) {
      _fetchSizeBytes =
          Integer.parseInt(props.getProperty("consumer.fetchsizebytes"));
      _bufferSizeBytes = _fetchSizeBytes;
    }

    if (props.getProperty("consumer.min.fetchsizebytes") != null)
      _minFetchSizeBytes =
          Integer.parseInt(props.getProperty("consumer.min.fetchsizebytes"));

    if (props.getProperty("consumer.fillfreqms") != null)
      _fillFreqMs = Integer.parseInt(props.getProperty("consumer.fillfreqms"));

    if (props.getProperty("consumer.stopgracefully") != null)
      _stopGracefully =
          Boolean.parseBoolean(props.getProperty("consumer.stopgracefully"));

    if (props.getProperty("consumer.backpressure.enabled") != null)
      _backpressureEnabled =
          Boolean.parseBoolean(props
              .getProperty("consumer.backpressure.enabled"));

    if (props.getProperty("consumer.backpressure.proportional") != null)
      _proportional =
          Double.parseDouble(props
              .getProperty("consumer.backpressure.proportional"));

    if (props.getProperty("consumer.backpressure.integral") != null)
      _integral =
          Double.parseDouble(props
              .getProperty("consumer.backpressure.integral"));

    if (props.getProperty("consumer.backpressure.derivative") != null)
      _derivative =
          Double.parseDouble(props
              .getProperty("consumer.backpressure.derivative"));

      _stateConf = HashMap(ConstConfig.ZOOKEEPER_HOSTS->zkHost,
                      ConstConfig.ZOOKEEPER_PORT-> zkPort,
                      ConstConfig.KAFKA_TOPIC->kafkaTopic,
                      ConstConfig.ZOOKEEPER_BROKER_PATH-> brokerZkPath,
                      ConstConfig.ZOOKEEPER_CONSUMER_PATH-> consumerZkPath,
                      ConstConfig.ZOOKEEPER_CONSUMER_CONNECTION-> consumerConnection,
                      ConstConfig.KAFKA_CONSUMER_ID-> consumerId)

   /* _stateConf.put(Config.KAFKA_MESSAGE_HANDLER_CLASS, props.getProperty(
        "kafka.message.handler.class",
          "com.instartlogic.calves.kafka.spark.IdentityMessageHandler"));
	*/
  }
    
    
  
    
  
  
}