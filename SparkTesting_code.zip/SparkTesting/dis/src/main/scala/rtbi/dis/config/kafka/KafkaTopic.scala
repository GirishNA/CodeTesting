package rtbi.dis.config.kafka

class KafkaTopic {
  
}