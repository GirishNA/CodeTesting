package rtbi.dis.config

object ConstConfig {
  
  
   /**
   * Kafka  configurations
   */
  val ZOOKEEPER_HOSTS:String = "zookeeper.hosts"
  val ZOOKEEPER_PORT:String = "zookeeper.port"
  val KAFKA_TOPIC:String = "kafka.topic"
  val ZOOKEEPER_BROKER_PATH:String = "zookeeper.broker.path"
  
    /**
   * Consumer  configurations
   */
  val ZOOKEEPER_CONSUMER_PATH:String = "zookeeper.consumer.path"
  val ZOOKEEPER_CONSUMER_CONNECTION:String ="zookeeper.consumer.connection"
  val KAFKA_CONSUMER_ID:String = "kafka.consumer.id"
  
  
  /**
   * Optional Configurations
   */
  val KAFKA_PARTITIONS_NUMBER ="kafka.partitions.number"
  val CONSUMER_FORCE_FROM_START ="consumer.forcefromstart"
  val CONSUMER_FETCH_SIZE_BYTES ="consumer.fetchsizebytes"
  val CONSUMER_FILL_FREQ_MS = "consumer.fillfreqms"
  val CONSUMER_STOP_GRACEFULLY ="consumer.stopgracefully"
  
  
    /**
   * Configuration to Back Pressure
   */
  
  
 val  CONSUMER_BACKPRESSURE_ENABLED ="consumer.backpressure.enabled"
 val CONSUMER_BACKPRESSURE_PROPORTIONAL ="consumer.backpressure.proportional" 
 val  CONSUMER_BACKPRESSURE_INTEGRAL ="consumer.backpressure.integral"
 val CONSUMER_BACKPRESSURE_DERIVATIVE ="consumer.backpressure.derivative"
 val  KAFKA_RECEIVER_NUMBER = "kafka.receiver.number"
 val KAFKA_MESSAGE_HANDLER_CLASS ="kafka.message.handler.class"
  
}