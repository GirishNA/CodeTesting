package rtbi.dis.config

/**
 * Created by Roop on 14 march 2016 .
 */
import java.util.Properties
import java.io.FileInputStream
import scala.collection.JavaConverters._


object LoadResources {
  
  
  //Read the properties from the .properties file and return all properties .
  
  def returnAsProperties(resourceFile:String):Properties={
   val prop = new Properties
   prop.load(this.getClass.getResourceAsStream(resourceFile)) 
   prop
  }
  
  //Return properties file value as Map
  def propertiesAsMap(resourceFile:String):Map[String , String]={
   val prop = new Properties
   prop.load(this.getClass.getResourceAsStream(resourceFile)) 
   prop.asScala.toMap
  }
  
   
}