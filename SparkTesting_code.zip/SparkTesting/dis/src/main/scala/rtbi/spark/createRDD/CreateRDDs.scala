package rtbi.spark.createRDD

import rtbi.spark.sparkConnect.SparkConnection
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.Row
import play.api.libs.json.Json
import org.apache.spark.rdd.RDD
//import org.junit.runner.Computer

case class Employee(Name:String,Age:String,Salary:Int)


object CreateRDDs {
  val sparkSession=SparkConnection.sparkSession
  val sparkContext=SparkConnection.sparkContex
  def main(args:Array[String])
  {
    //createRDDUsingStructurType();
    //createRDDUsingCaseClass();
    //createRDD();
    rddCodeTesting
  }
  
  /*
   * In this class we creating RDD without case class and This is used when we get dynamic column names and that columns are converted in Structure Type
   */
  def createRDDUsingStructurType()
  {
    val columnNames="Name,Age,Salary"
    val columnSchema=StructType(columnNames.split(",").map(fields=>StructField(fields,StringType,true)))
    
    val data="ram,25,100000"
    
    val seqData=data.split(",")
    val rowRDD:Row=Row(seqData(0),seqData(1),seqData(2))
    
    val createRDD=sparkSession.createDataFrame(sparkContext.makeRDD(Seq(rowRDD)), columnSchema).show()
   
    
    //or
    val createRDD_2=sparkSession.createDataFrame(sparkContext.makeRDD(Seq(Row.fromSeq(data.split(",")))),columnSchema).show()
    
  }
  
  /*
   * Creating the Data frame using the case class ->When we knows the all column names then we can create RDD through case class
   */
  def createRDDUsingCaseClass()
  {
    //val data="ram,25,10000"
    val createRDD=sparkSession.createDataFrame(sparkContext.makeRDD(Seq(Employee("x","y",1)))).show()
  }
  
 def createRDD()
 {
   val createRDD=sparkContext.parallelize(Seq(1 to 100),4)
   println("------>"+createRDD)
   println("------>"+createRDD.getNumPartitions)
   
   val createRDD_2=sparkContext.makeRDD(Seq(4 to 100))
   println("----->"+createRDD_2)
   println("------>"+createRDD_2.getNumPartitions)
   println("----->"+createRDD_2.repartition(4).getNumPartitions)
 }
 
 def rddCodeTesting()
 {
   val data=sparkContext.parallelize(1 to 5,4)
   
   data.foreach(x=>println(x))
   println(data.partitioner)
  //  println(data.compute( , 1))
   
 }
 
  
}