package rtbi.spark.files

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StringType
import org.apache.spark.streaming._
import org.apache.spark.sql.streaming.StreamingQuery
import scala.collection.mutable.ListBuffer
import play.api.libs.json.Json
import org.json._


object ReadFiles {
  
  val sparkSession=SparkSession.builder().master("local").appName("readFiles").getOrCreate();
  val sparkContext=sparkSession.sparkContext
  
   //(sparkSession,Seconds(2))
  import sparkSession.implicits._
  val streaming=sparkSession.streams
  import streaming._
  
  def main(args:Array[String]){
    //readCsvFile()
   // streamData()
   // readParquetFile()
    
    writeIntoCSV()
    
    
  }
  
  /*
   * Reading csv file from the source. Two ways we can read the csv file using the 'format' key word or 
   * we can directly read through csv keyword
   */
  def readCsvFile()
  {
    //First way of the reading csv file using 'format' key word
   var csvData1=sparkSession.read.format("csv").csv("/home/vtpl/disTest/csv/orders.csv");
   csvData1.show();
   
   //Reading row by row data using 'collect' key word Through for loop
   /*for(eachRecord<-csvData1.collect)
   {
     println(eachRecord)
     Thread.sleep(1000)
   }*/
   
   //Second way of the reading csv file using 'csv' key word
   var csvData2=sparkSession.read.csv("/home/vtpl/disTest/csv/test.csv")
   csvData2.show();
   
   //Reading data with headers using 'option' key word
   var csvHeadersData=sparkSession.read.option("header", "true").csv("/home/vtpl/disTest/csv/orders.csv")
   csvHeadersData.show();   
   

   
  
   
 //  println("------>"+csvStreamData)
   
  }
  
  def streamData()
  {
    //Reading stream of data
   val headers="CID,CFName,CLName,CPID,PName,CFTID,TName,CEmail,DCreated,Ctype,ustamp"
   val schema=StructType(headers.split(",").map(feilds=>StructField(feilds,StringType,true)))
   var csvStreamData=sparkSession.readStream.schema(schema).csv("/home/vtpl/disTest/csv/orders.csv")
 // csvStreamData.show();
   // var csvStreamData=sparkSession.readStream.parquet("/home/vtpl/disTest/testing.parquet")
    println("------------->"+csvStreamData.isStreaming)
    
  //  csvStreamData.writeStream.outputMode("append").format("parquet").option("checkpointLocation", "/home/vtpl/xx1.parquet").start("/home/vtpl/xx.parquet")
    
    //csvStreamData.writeStream.outputMode(org.apache.spark.sql.streaming.OutputMode.Append).format("parquet").option("checkpointLocation", "/home/vtpl/xx1.parquet").start("/home/vtpl/xx.parquet")
csvStreamData.writeStream.outputMode("Append").format("parquet").start("/home/vtpl/disTest/xx.parquet")
  
  /*csvStreamData.write.mode(org.apache.spark.sql.SaveMode.Append).parquet("/home/vtpl/disTest/streamData.parquet")
  // csvStreamData.show() */
 val readParquet=sparkSession.read.parquet("/home/vtpl/xx.parquet")
   //readParquet.show();
 readParquet.createOrReplaceTempView("text")
 val x=sparkSession.sql("select * from text")
  
  }
  
  def readParquetFile()
  {
    var parquetData=sparkSession.read.csv("/home/vtpl/disTest/csv/orders.csv")
      parquetData.write.mode(org.apache.spark.sql.SaveMode.Append).parquet("/home/vtpl/disTest/testing.parquet")
      val readParquet=sparkSession.read.parquet("/home/vtpl/disTest/testing.parquet").show()
  
  }
  
  
  def writeIntoCSV()
  {
    val records=sparkSession.read.format("csv").csv("/home/vtpl/disTest/csv/orders.csv")
    
    println("---->"+records.first())
    
    records.write.mode(org.apache.spark.sql.SaveMode.Overwrite).csv("/home/vtpl/disTest/csv/111.csv")
  }
  
 
  
  
  
  
}