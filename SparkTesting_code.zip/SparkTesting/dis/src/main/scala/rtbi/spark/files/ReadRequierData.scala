package rtbi.spark.files

import org.apache.spark.sql.SparkSession

object ReadRequierData {
  
  val sparkSession=SparkSession.builder().master("local").appName("dataFile").getOrCreate()
  
  import sparkSession.implicits._
  
  def main(args:Array[String])
  {
    readFile()
  }
  
  
  def readFile()
  {
    val read=sparkSession.read.option("header", "true").csv("/home/vtpl/Documents/CLAIMS_DATA/BiharDump.csv")
    
   //println( read.count)
    
  /*  val data=read.select("HospitalName", "RegistrationUserDate")//.filter("HospitalName=MGM Medical College")
    
   data.show()*/
   
   read.createOrReplaceTempView("data")
   val d="#20/08/2015#"//"MGM Medical College"
   val d1="#30/08/2015#"
   val readTable=sparkSession.sql(s"select * from data where RegistrationUserDate BETWEEN 20/08/2015 AND 30/08/2015")
   
   readTable.show()
   
   
  }
}