package rtbi.spark.json

import org.json._
import rtbi.spark.sparkConnect.SparkConnection

object ReadInnerJson {
  val sparkSession=SparkConnection.sparkSession;
  val sparkContext=SparkConnection.sparkContex;
  def main(args:Array[String])
  {
    convertInnerArrayJsonToNormalJson()
  }
  /*
   * This convertInnerArrayJsonToNormalJson() method is used to read the inner Json array data and 
   * store the some values into the normal Json Array.
   */
  def convertInnerArrayJsonToNormalJson()
  {
    var firstJson:Any=null;
    var arrayJson=new JSONArray();
    var index=0;
    var typeIndex=0;
    var counter=1;
    
    //This is the json data to read and its having the inner json Array
    val jsondata="""{"aggregateDefinition":[{"aggregateId":1,"aggregateName":"aggregate user","aggregateDesc":"aggregate desc","columnName":"MemberState","columnType":"String","aggType":[{"typeId":3,"type":"count1"},{"typeId":4,"type":"groupBy1"}]},{"aggregateId":2,"aggregateName":"aggregate22","aggregateDesc":"aggregate2 desc","columnName":"PatientName","columnType":"String","aggType":[{"typeId":3,"type":"count2"},{"typeId":4,"type":"groupBy2"}]}]}"""

    //Converting the string data to the json data 
    val aggInfo=sparkSession.read.json(sparkContext.parallelize(jsondata :: Nil))
    
    //Taking the outer Array of json size 
    val firstCounter= aggInfo.select("aggregateDefinition.aggregateId").collectAsList().get(0).getList(0).size()   
   
       println("***************--------------->"+firstCounter)

    aggInfo.createOrReplaceTempView("JsonAggData")
    
   while(counter<=firstCounter)
   {
     // val x= aggInfo.select("aggregateDefinition.aggType[1]").collectAsList().get(0).getList(0)//.size() 
     
     
     //Taking the inner Array of json size
     val secondCounter=sparkSession.sql(s"select aggregateDefinition.aggType[$index] from JsonAggData where aggregateDefinition.aggregateId[$index]=$counter").collectAsList().get(0).getList(0).size()
     println("***************------------------>"+secondCounter)
   
     while(typeIndex<secondCounter)
     {
         //Taking the requier Json Data and converting into the another json
         firstJson=new JSONObject(sparkSession.sql(s"select aggregateDefinition.columnName[$index] AS columnName ,aggregateDefinition.aggType[$index].type[$typeIndex] AS type from JsonAggData where aggregateDefinition.aggregateId[$index]=$counter AND aggregateDefinition.aggType[$index].typeId[$typeIndex]=(select aggregateDefinition.aggType[$index].typeId[$typeIndex] from JsonAggData )").toJSON.collectAsList().get(0))//.toString())//.get(0).get(0)//.toJSON.collectAsList().get(0)
         
         //Storing into the array of Json 
         arrayJson.put(firstJson)
         println(counter+"----------------------------------------------------------------->"+firstJson)
         typeIndex+=1
       }
     
     index+=1
     counter+=1
   }
    
   println(counter+"----------------------------------------------------------------->"+arrayJson)
  
   //Converting all json array data into the one json object with key value pair
   val finalJson=scala.util.parsing.json.JSONObject(Map("testing"->arrayJson))
   println("Final Json--------------------->"+finalJson)
   
   //Result is :-"{"testing" : [{"type":"count1","columnName":"MemberState"},{"type":"groupBy1","columnName":"MemberState"}]}"
   
  }
}