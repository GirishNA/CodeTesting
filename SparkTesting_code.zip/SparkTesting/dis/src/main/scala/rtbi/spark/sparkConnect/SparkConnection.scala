package rtbi.spark.sparkConnect

import org.apache.spark.sql.SparkSession

object SparkConnection {
  val sparkSession=SparkSession.builder().master("local").appName("Testing").getOrCreate();
  val sparkContex=sparkSession.sparkContext;
  import sparkSession.implicits._;
}