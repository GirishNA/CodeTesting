package rtbi.scala.pgmtesting

object SumOfSubSets {
  def main(args:Array[String])
  {
   val a=List(1,2,3,4,5,6,7)
    val target=8 
    var n=0
   // sumOfSubSets
    sumOfSubSets_1
    val resu=sumOfSubSets_2(a,target,n)
    println(resu)
  }
  
  def sumOfSubSets()
  {
    val a=List(1,2,3,4,5,6,7)
    val target=8
    var b=List.empty[List[Int]]
    
  
    var c=0
    var x=0
  
    while(x != a.length && c != a.length)
    {
      var d=List.empty[Int]            
      var sum=(a(c)+a(x+1))
      if(target == sum)
      {       
        d+:=a(x+1)
        d+:=a(c)
        b+:=d
       
       c+=1
       x=0
      }
      if(target < sum)
      {       
       x=a.length-1
      }      
      /*println("***"+x+"\t"+a.length+"\t"+c)
      if(x == a.length-1)
      {
        println("--->"+x)
        c+=1
        x=0
      }*/
         x+=1;
     
    }
    println(b)
  }
  
  
  def sumOfSubSets_1()
  {
    val a=List(1,2,3,4,5,6,7)
    val target=13
    var st=Set.empty[Int]
    var lt=List.empty[(Int,Int)]
    
    
    
    for(i<-0 to a.length-1)
      {
        var res=target-a(i)
        if(st.contains(res))
        {
         var l=(a(i),res)
         lt::=l          
        }
        st+=a(i) 
       // println(st)
       // println("---->"+lt)
      }
    println("---->"+lt)
  }
  
  def sumOfSubSets_2(a:List[Int],target:Int,n:Int):Any=
  {
     var lt=List.empty[(Int,Int)]
     var i=n
     if(i != a.length)
     {
     //  var res=target-
       
       i+=1
       return sumOfSubSets_2(a,target,i)
     }
  }
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
 }