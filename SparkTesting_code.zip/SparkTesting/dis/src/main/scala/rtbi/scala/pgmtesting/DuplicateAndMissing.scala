package rtbi.scala.pgmtesting

object DuplicateAndMissing {
  
  def main(args:Array[String])
  {
    val num=List(3,2,2,3,1,3,4,3,5,6,1)
    
    val num1=List(3,2,1,4)
    val range=1 to 10
    duplicateInRange(num)
   // missingNumInRange(num,range)
  }
  
  def duplicateInRange(num:List[Int])
  {
 
   
   var res=Map.empty[Int,Any]
    
 
   //1 st way 
   (num.min to num.max).map(y=>res+=(y->num.count(x=>x.equals(y))))
  
  println("--->1\t"+res)
  
  
    //2 nd way 
    ((1 to 6).map(y=>res+=(y->num.count(_.equals(y)))))
  
    println("--->2\t"+res)
    
    
    //3 rd way 
    for(i<-1 to 10)
    {
      res.empty
      var count=0;
       var increment=0
      while(num.length > count)
      {       
        if(num(i)==num(count))
        {
          increment+=1
          res+=(num(i)->increment)
        }
        count+=1
      }
    }

   println("2 nd time "+res) 
   
  }
  
  
  def missingNumInRange(num:List[Int],range:Range)
  {
    
    
    var l=List.empty[Int]
    //1 st way 
    range.map(y=>if(!num.contains(y))l::=y)
    
    println(l.sorted)
    
   // range.map(y=>if(!num.(_.==(y))))l::=y)
    
    var l1=Set.empty[Int]
    
    // 2 nd way 
    var l2=List.empty[Int]
    
    for(i<-1 to 10)
    {
      var count=0
      var condition=0
      while(num.length > count)
      {
       if(num(count) == i )
       {
         //count=num.length
         condition+=1;
       }
       count+=1
      }
      if(condition == 0)
      {
        l2+:=i
      }
    }
    
    println(l2.sorted)
    
    
    
  }
  
}