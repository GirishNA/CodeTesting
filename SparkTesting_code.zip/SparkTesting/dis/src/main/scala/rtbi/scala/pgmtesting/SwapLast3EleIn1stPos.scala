package rtbi.scala.pgmtesting

import scala.collection.mutable.ArrayBuffer


object SwapLast3EleIn1stPos {
  def main(args:Array[String])
  {
    println("Enter 1 to continue........")
    if(Console.readInt==1)
    {
     println("Enter number\n") 
    val num=Console.readInt()
    
   // swapLast3EleIn1stPos(num)
    swapLast3EleIn1stPos1(num)
    }
  }
  
  
  /* input-> 10
   * output-> 7,8,9,1,2,3,4,5,6,10
   * input-> 20 
   * output-> 7,8,9,17,18,19,1,2,3,4,5,6,10,11,12,13,14,15,16,20 
   */
  
  def swapLast3EleIn1stPos(num:Int)
  {
    var count=1
    var finalRes=ArrayBuffer[Int]()
    var res=ArrayBuffer[Int]()
   
     for(i<-1 to num)
     {      
      
      if(7<=count || 9 <=count)
      {
        finalRes+=i
      }
      else{
        
        res+=i
      }
      count+=1
      if(count==10)count=0
        
    }
    for(value<-res)
    {
      finalRes+=value
    }    
    println(finalRes)
  }



  def swapLast3EleIn1stPos1(num:Int)
  {
    var finalRes=ArrayBuffer[Int]()
    var res=ArrayBuffer[Int]()
   (1 to num).map(x=>if(x%10>=7 && x%10<=9) finalRes+=x else res+=x);finalRes.appendAll(res) 
    
  
    println("--->"+finalRes)
    
  }

}
