package rtbi.scala.pgmtesting

import scala.util.Random
import java.lang.Math

object RandomOddAddNum {
  def main(args:Array[String])
  {
   randomNum(1,5) 
  // oddNums()
  // addNumUsingMap()
  }
  
  def randomNum(start:Int,end:Int)
  {
    var rand=new Random()
    /*var (a,b)=(start,end)
    for(x<-1 to b)
    {
      if(a>b)
      {
          a-=b
          println("--> "+a)
      }
      else{
            b-=a
             println("--> "+b)        
          }
    }
    
    
    
    //val m=new Math()
    var res=0
    
   
    
    while(res>a || res<=b)
    {
      res=( (b - a +1))
    }*/
    
    
    var result= rand.nextInt(end)
    println("result is \t"+result)
    
    
  }
  
  
  
  
  def oddNums()
  {
    for(i<-0+1 to 10 by 2 )
    {
      println(i)
    }
    println("----------------------->")

    
    val x=(0 to 10).foreach(println)
    
    println("----------------------->")
    
    val y=(0 to 10 by 2).map(println)
  }
  
  
  def addNumUsingMap()
  {
    val y=(0 to 10).map(i=>i+i)
    println(y.last)
    
    val x=List(1,2,3,4)
    val a=x.map(i=> i.+(i))
    println("----->"+a)
    
    val arr=Array(1,2,3)
    val res1=arr.map(i=>println(i+i))
 //  println(res1)
  }
  
  
  
  
  
}