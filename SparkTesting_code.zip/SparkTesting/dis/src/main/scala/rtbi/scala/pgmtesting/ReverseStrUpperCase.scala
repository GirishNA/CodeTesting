package rtbi.scala.pgmtesting

object ReverseStrUpperCase {
  def main(args:Array[String])
  {
    revStrUpperCase("HI GOOD")
  }
  
  def revStrUpperCase(strData:String)
  {
    val rev=strData.split(" ").map(x=>x.toLowerCase())                              //mkString(" ")    println(rev)
     
    val revData=(("" /:strData.toLowerCase())(_.+:(_))).split(" ").map(_.capitalize).mkString(" ")
  
    println(revData)
  
    val revData1=((("":\strData.toLowerCase()))(_+(_)))
    println(revData1)
    
    val revData2=(((strData.toLowerCase():\""))((a,b)=>b+a)).split(" ").map(_.capitalize).mkString(" ")
    
    println(revData2)
  
  
  }
}