package rtbi.scala.pgmtesting

class Calculator {
  
 /* val c=(x:Int,y:Int)=>   //x+y
    { val result=x+y
   //println(result) 
   result
    }*/
    
    
    
    def applya(f:(Int,Int)=>Int,x:Int,y:Int)=f(x,y)
  
    def add(a:Int,b:Int)=a+b
  
    
  
  
}