package rtbi.scala.access.specifiers


class Outer{
  new Inner
  class Inner{
    print("Inner method")
    private def print(method:String)=println(s"HI am in $method method")
    new InnerOuter
    class InnerOuter{
      print("calling from InnerOuter")
    }
  }
  
}

object Private {
  def main(args:Array[String])
  {
    new Outer
  }
}