package rtbi.scala.pgmtesting

object AddDigitFromString {
  
  
  def main(args:Array[String])
  {
    val str="a2bc3d"
    //addDigit(str)
    addDigit1(str)
  }
  

  def addDigit(str:String)
  {
    var res=0
  
    for(data<-str.toCharArray())
    {
      if(data.isDigit)
      {
        println("-->"+data.toString().toInt)
       res+=data.toString().toInt 
       println("result\t"+res)
      }
    }
    println("result\t"+res)
  }
  
  def addDigit1(str:String)
  {
    var res=0
    str.toCharArray().map(x=>if(x.isDigit)res+=x.toString().toInt)
    
    println("---->"+res)
  }

  
}

