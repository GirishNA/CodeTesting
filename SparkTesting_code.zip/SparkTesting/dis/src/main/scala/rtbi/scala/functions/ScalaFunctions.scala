package rtbi.scala.functions

object ScalaFunctions {
  def main(args:Array[String])
  {
    
  }
  
  
}