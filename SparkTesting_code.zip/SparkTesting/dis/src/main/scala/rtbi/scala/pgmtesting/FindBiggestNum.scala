package rtbi.scala.pgmtesting


object FindBiggestNum {
  def main(args:Array[String])
  {
     var strData="thisisavalidsentencexyz"
    findBiggestNum(342190768)
   // getDataFromDictionay(strData)
  }
  
  def findBiggestNum(num1:Int)
  {
    var num=num1
    var rev:List[Int]=List.empty
    var res=0
    var i=1
    
    while(num>0)
    {
     rev::=num % 10      
     num=num / 10
     
     //res=res*10+rev
     //num=num*10
    /* while(i>0 && num >0)
     {
     
      val x= (rev.maxBy(x=>x.max(rev(i))))
      println(x)
     }*/
    
     println("giri---->\t"+rev.slice(0, i))
     
     println("max---->\t"+rev.slice(0, i).max) 
     
    i+=1    
    }
  //  println("-->"+rev.foldLeft(0)((x,y)=> y max x))
    println("-->"+rev.reduce(_ max _))
    
    println("-->"+rev.sorted(Ordering.Int.reverse))
    
     println("-->"+rev.sortBy(_.shortValue()).reverse)
     
     println("-->"+rev.sortBy(_.shortValue()).reverse.foldLeft("")(_+_))
     
     println("-->"+rev.sortWith(_>_).foldLeft("")(_+_))
     
     println("-->"+rev.sortWith((x,y)=>x > y).foldLeft("")(_+_))
     
     
    var ab=""
    for(x<-0 to rev.size)
    {
   //  rev.reduceLeft((a,b)=>ab+=(a max b))//.foreach()
     ab+=rev.reduceLeft(_ min _)
    }
    println("----->"+ab)
    
  //  rev.foldRight()
    //rev.sliding(rev.size).max(Ordering[B])
    //rev.map(_.max(rev.sliding(3)))
    rev.slice(0, i).max
    println(res)
    
    val d="658"
    
   var x= d.toCharArray()
   
   //x.
   
  //  var r:Array[Int]=Array.empty
    /*for(i<-d)
    {
        //=i.toInt
    }*/
    
    //val data="658"
    
  }
  
  
  def getDataFromDictionay(strData:String)
  {    
      val dictionary=List("is","this","a","valid","sentence","xyz")
      
     val disMap=Map(1->"this",2->"is",3->"a",4->"valid",5->"sentence")
   
    // 1st way for the serching dictionary data using map 

    var x= ""
    
    for(i<-1 to disMap.size)
    {
    val y=strData.contains(disMap(i))
    
    if(y){
      x+=disMap(i)+" "
    }
    }
    println("---->"+x)
    
    
    
  
       
    
    // 2nd way for the serching dictionary data using list 
    
   var xy=strData.toCharArray()
   var y1=""
   var res=""
    for(i<-0 to xy.length-1)
    {      
      y1+=xy(i).toString()   
      if(dictionary.find(_==y1) != None)
      {        
        res+=y1+" "       
        y1=""
      }
          
    }    
    println("result \t "+res)
    
    
    
    
  }
  
  
}