package rtbi.scala.pgmtesting

object PatternPgm {
  
  def main(args:Array[String])
  {
    val num=5
    val z=0;
    val h=1;
    val b=1;
   // pattern1(num)
    //pattern2(num)
   // println(pattern3(z,h,b))
    pattern4(num)
  }
  
  /*
   * n=4
   * 4444
   * 3444
   * 2344
   * 1234
   */
  
  def pattern1(num:Int)
  {
    var b=num
    for(i<-1 to num)
    {     
      var a=num+1
       a-=i
      for(x<-1 to i)
      {        
        print(a)
         a+=1
      }
      for(j<-num-i to 1 by -1)
      {
        print(b)
      }
      println()
      }
  }
  
  /*
   * n=4
   *    1
   *   232
   *  45654
   * 78910987
   */
  def pattern2(num:Int)
  {
    var a=1
    var b=1
    var space=num-1
    for(i<-1 to num)
    {
      for(y<-1 to space)
      {
        print(" ")
      }
      for(j<- 1 to i)
      {
        print(a)
        a+=1
      }
      b=a-1
      for(x<-1 to i-1)
      {
        b-=1
        print(b)        
      }
      space-=1
      b+=1
      println()
    }
  }
  
  /*
   * return true/false 
   * z*z*z+h*h=b*b*b
   */
  
  def pattern3(z:Int,h:Int,b:Int):Boolean=
  {
    var a=z*z*z+h*h
    var c=b*b*b
    println(a+"\t"+c)
    if(a==c)
    {
      return true
    }
    false
  }
  
  
  
   /*
     n=5
      *
     * *
    * * *
   * * * *
  * * * * *
  * * * * *
   * * * *
    * * *
     * *
      *
   */
  
  def pattern4(num:Int)
  {
    var space=" "
    for(i<-1 to num)
    {
      for(x<-i to num)
      {
        print(space)
      }
      for(j<-1 to i)
      {
        print(space+"*")
      }
      println()
    }
    for(i<-num to 1 by -1)
    {
      for(x<-i to num)
      {
        print(space)
      }
      for(j<-1 to i)
      {
        print(space+"*")
      }
      println()
    }
  }
  
  
}













