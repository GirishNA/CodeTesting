package rtbi.scala.pgmtesting

object Swap2Num {
  def main(args:Array[String])
  {
    println("Enter first number")
    var a=Console.readLine();
    
    println("Enter second number")
    var b=Console.readLine();    
    
    swap2Num(a.toInt,b.toInt)
  }
  
  def swap2Num(num1:Int,num2:Int)
  {
    var a=num1;
    var b=num2;
    a=a+b;
    b=a-b;
    a=a-b;
    
    println("old numbers\t"+num1+"\t"+num2)
    println("swaped numbers\t"+a+"\t"+b)
    
  }
}