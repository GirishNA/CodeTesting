package rtbi.scala.pgmtesting

object SortArrayElements {
  def main(args:Array[String])
  {
    val data=Array(0,0,1,1,0,0,1,0,0,1,1)
    sortArrayElements(data)
   // sortArrayElem(data)
  }
  
  /*
   * input ->  Array(1,0,1,0,0,0,1,0,1,1,1)
   * output->  Array(1,1,1,1,1,1,0,0,0,0,0)
   */
  
  def sortArrayElements(data:Array[Int])
  {
    
    
    var j=data.length
    println(j)
    
    for(i<-0 to data.length-1)
    {
     println("data--->"+data(i))
      for(j<-0 to data.length-1)
      {
        println("----->"+j)
      if(data(i)>data(j))
      {
        println(i+"---->"+data(i))
        println(j+"---->"+data(j))
        
        
        var temp=data(j)  
        data(j)=data(i)
        data(i)=temp
        
        
      }
      else{
        j+data.length-1
      }
       
      }
    }
    print("\n\n---->")
    for(x<-data){
    print("\t"+x)}
  }  
  
}