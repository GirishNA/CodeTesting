package rtbi.scala.pgmtesting

object LeastCommonElement {
  def main(args:Array[String])
  {
    val dataA=Array(5,5,4,5,4,6,6,6,1,3,3,4,4,5,4)
    secondLeastElement(dataA)
  }
  
  
  def secondLeastElement(dataA:Array[Int])
  {
    var list=Map.empty[Int,Int]
     (dataA.min to dataA.max).map(x=>list+=(x->(dataA.count(_.equals(x)))))
     
     println(list)
     
     println(list.min)
     
     println(list.max)
     
     for(i<-1 to list.size)
     {         
      
       if(list(i) != 0)
       {
         for(j<- 1 to list.size)
         {
             println(list(j))
         }
       }
     }
  }
}