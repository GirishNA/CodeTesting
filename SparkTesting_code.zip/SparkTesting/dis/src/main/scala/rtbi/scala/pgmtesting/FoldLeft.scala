package rtbi.scala.pgmtesting

object FoldLeft {
  def main(args:Array[String])
  {
    addNum
    strReverse
  }
  
  def addNum()
  {
    val x=List(1,2,3,4,5)

    
    println( x.foldLeft(0)((a,b)=>b-a))
 
    
   println( x.foldRight(0)((a,b)=>b-a))
  }
  
  
  
  def strReverse()
  {
    val str="abc"
    println((str.foldLeft("")((a,b)=>(b+a))))
  }
}