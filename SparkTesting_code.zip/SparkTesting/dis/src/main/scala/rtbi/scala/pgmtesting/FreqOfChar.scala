package rtbi.scala.pgmtesting

object FreqOfChar {
  def main(args:Array[String])
  {
    var strData="abbcaad"
    freqOfCharacter(strData)
  }
  
  def freqOfCharacter(strData:String)
  {
    var countMap=Map.empty[Char,Int]
    val charData=strData.toCharArray()
    for(i<-0 to strData.length()-1)
    {
      var counter=0
      for(j<-0 to strData.length()-1)
      {
        if(charData(i)==charData(j))
        {
          counter+=1
        }
      }
      countMap+=(charData(i)->counter)
    }    
    println("--->"+countMap)
    
   /* var countMap1=Map.empty[Char,Int]
    var count=0
   (0 to strData.length()-1).map(i=>((0 to strData.length-1).map(j=>if(charData(i)==charData(j))println((count+=1)))))
   
   println("2--->"+count)*/
  }
}