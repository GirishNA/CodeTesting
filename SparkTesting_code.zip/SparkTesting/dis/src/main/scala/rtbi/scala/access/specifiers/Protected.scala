package rtbi.scala.access.specifiers

class Super
{
  protected def print(){println("Hi this is super class")}
}

class Sub extends Super{
  print()
  println("I am inside the sub class")
}






object Protected {
  def main(args:Array[String])
  {
    new Sub
  }
}