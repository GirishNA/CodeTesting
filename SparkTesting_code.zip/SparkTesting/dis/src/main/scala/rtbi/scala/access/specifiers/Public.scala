package rtbi.scala.access.specifiers

class PublicDeclaration
{
  def print()=println("I am in PublicDeclaration class")
}

class SubPublic
{
  (new PublicDeclaration).print()
}


object Public {
  def main(args:Array[String])
  {
    (new SubPublic)
  }
}