package rtbi.scala.pgmtesting

object ReplaceDegitToX {
  def main(args:Array[String])
  {
    val data1="123456789"
    val data2="My Creadit Card year 2016 number is 12345678"
    replaceDegitToX1(data1)
    //replaceDegitToX2(data2)
    replaceDegitToX3(data2)
  }
  
  
  // 1st way of the replacing the digit to "X"
  def replaceDegitToX1(digit:String)
  {
    val digitArr=digit.toCharArray()
    var finalData=""
    
    for( i <- 0 to digit.length()-1)
    {
      if(i >= 2 && i <= digit.length()-3)
      {
        finalData+="x"
      }
      else{
          finalData+=digitArr(i)
      }
    }
    println("--->"+finalData)
  }
  
   // 2nd way of the replacing the digit to "X"
  def replaceDegitToX2(data:String)
  {
    val dataArr=data.toCharArray()
    var finalData=""
    
    for(i<-1 to data.length()-1)
    {
      if(dataArr(i).isDigit)
      {
        finalData+="x"
      }else{
        finalData+=dataArr(i)
      }
      
    }
    println("--->"+finalData)
  }
  
    // 3rd way of the replacing the digit to "X"

  def replaceDegitToX3(data:String)
  {
    var regex="""[0-9]""".r
    var y=regex.replaceAllIn(data, "x")
    println("--->"+y)
    var regex1="""^\d+""".r
    var a=regex1.replaceAllIn("1234giri", "x")
    println("---->"+a)
    
  }
  
  
  
  
  
}