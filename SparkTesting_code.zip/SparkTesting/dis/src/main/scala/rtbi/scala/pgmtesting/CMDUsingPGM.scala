package rtbi.scala.pgmtesting

import sys.process._

object CMDUsingPGM {
  def main(args:Array[String])
  {
  //  val x=Seq("mkdir","/home/vtpl/1111111111") 
    
   // x !
    
   // val y=Seq("nc","-lk","9888") !
    
    //val pattern=Seq("java","-cp","/home/vtpl/Documents/SPARK/SparkTesting/dis/target/dis.jar","rtbi.scala.pgmtesting.PatternPgm") !
    
    /*val x="ls" !
    
    println(x)*/
    
   // copyFileToServer
    runTalend
  }
  
  def copyFileToServer()
  {
    val sent=Seq("scp","/home/vtpl/giri","vtpl@192.168.0.252:/opt/")
    val psw=Seq("admin@vtpl")
    //psw #| sent !
  }
  
  
  def runTalend()
  {
   // val cd=Seq("cd","/home/vtpl/Documents/TALEND/frameworkDISwithTag/frameworkDIS") !
    
   // val x="pwd" !
   // val l="ls" !
    val run = Seq("sh", "/home/vtpl/Documents/TALEND/frameworkDISwithTag/frameworkDIS/./frameworkDIS_run.sh", "--context_param", s"propertyFile=/home/vtpl/Documents/TALEND/disProp.txt") !

    //sh /home/vtpl/Documents/TALEND/frameworkDISwithTag/frameworkDIS/./frameworkDIS_run.sh --context_param propertyFile=/home/vtpl/Documents/TALEND/disProp.txt
  }
  
}