package rtbi.scala.pgmtesting

object RecursiveMeth {
  def main(args:Array[String])
  {
    val res=fact(5)
    
    println("---->"+res)
  }
  
  def fact(num:Int):Int=
  {
    def go(n:Int,acc:Int):Int=
      if(n<=0) acc else go(n-1,n*acc)    
     
      go(num,1)
    
  }
}