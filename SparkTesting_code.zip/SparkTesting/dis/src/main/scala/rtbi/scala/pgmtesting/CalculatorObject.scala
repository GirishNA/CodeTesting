package rtbi.scala.pgmtesting




object CalculatorObject {
  def main(args:Array[String])
  {
  // val c=new Calculator()
  // c.applya(add, 2, 2) 
   // val c=Calculator.applya(add,2,2)
    //println(c.applya(add,2))
    
   // c(2,3)(+)
    
    //println(c)
    
  // println(apply(add))
   // println(+(1))
   
  /*val c= (+(3))
  
  println(c)*/
  println(apply(dev,2,4))
   // apply(add)
  }
  
  //def apply(a:Int)=applya(add)
  
   def apply(calculatorFuction:(Double,Double)=>Any,a:Double,b:Double)=calculatorFuction(a,b)
  
   def add(x:Double,y:Double)=(x+y)
   
   def sub(x:Double,y:Double)=(x-y)
   
   def mul(x:Double,y:Double)=(x*y)
   
   def dev(x:Double,y:Double)=(x/y)
  
}