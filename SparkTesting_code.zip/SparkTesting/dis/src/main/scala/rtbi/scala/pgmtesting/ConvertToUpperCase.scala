package rtbi.scala.pgmtesting

object ConvertToUpperCase {
  def main(args:Array[String])
  {
   // stringToUpper("girish hi good")
   // forEachCondition("10")
    //sumOfVowelsConsonents("aci")
    //reverseString("abcg")
    add
  }
  
  def stringToUpper(strData:String)
  {
    val data=(strData.split(" ").map(x=>x.capitalize)).foreach(x=>println(x))    
    //or
    val dat=strData.split(" ").map(_.capitalize).mkString(" ")
    
    println(dat)
    //or
    val d1="girish xyz"
    for(d<-d1.split(" "))
    {
    var x=d.toCharArray()
        x(0)=x(0).toUpper
      val v=new String(x)
     println("--->"+v)
    }
   
    
    // map(x=>(((x.toCharArray())==x(0).toUpper))//apply(0).toUpper).toString())//.toUpper).toString())
    
    //println("**----->"+data)
    
   /* for(x<-data)
    {
      println("----->"+x.capitalize  )//toIterable.foreach(f=>f.toUpper).toString())                   //map(x=>x.toUpper).toString())
    }*/
  }
  
  def forEachCondition(range:String)
  {
    for(i<-1 to range.toInt)
    {
      println(i)
    }
    
    range.foreach(i=>println(i))
  }
  
  
  
  
  def sumOfVowelsConsonents(strData:String)
  {
    var sum=0
    val x=Seq('a','e','i','o','u')
   // println(strData.toCharArray().ensuring(y=>y.equals('a')) )                 //containsSlice(x))           
    //filter(x=>x.)
    for(charData<-strData)
    {
      if(charData=='a'||charData=='e'||charData=='i'||charData=='o'||charData=='u')
      {
        sum+=1
      }
      else{
        sum+=2
      }
      print(sum)
    // println( charData)
     // println(charData)
      
    }
    println("----->"+sum)
    sum=0
   
    strData.map(x=>sum+=(if(x.equals('a')||x.equals('i')||x.equals('o')||x.equals('e')||x.equals('u')) 1 else 2))
    
    
    val x1=(strData.split(" ").map(_.matches("[aeiou]")))
    
    sum =0
    sum+=(if(strData.matches("[a]")) sum+1 else sum+2)
    
    println("****"+sum)
  }
  
  
  def reverseString(strData:String)
  {
    var rev=""
    println(strData.length())
   
    //Using while loop reversing the String
    var count=strData.length()-1
    while(0<=count)
    {
      var x=strData.toCharArray()
      rev+=x(count)
    println(x(count))
       count-=1
    }
    println(rev)
    
    //Using for loop reversing the string 
    var revF=""
    var count1=strData.length()-1
    for(x<-0 to count1)
    {
     var y=strData.toCharArray()
          revF+=y(count1-x)        
    }
    println("--->"+revF)
    
   /* var revs=""
    var counter=strData.length()-1
    var x=strData.filter(x=>x.)
    revs+=x
    println("-#-->"+x)
    println("**"+revs)*/
    
    strData.toCharArray()
    
    
    def reverse(s : String)=("" /:s)(_.+:(_))
    
     def reverse1(s : String)=("" /:s)((a,x)=>x+a)
    
  }
  
  def add()
  {
    val x=List(1,2,3,4,5)
    val sum=0
    
    val z=x.map(c=>c+c)
    println(z)
  }
  
  
  
  
  
  
  
}